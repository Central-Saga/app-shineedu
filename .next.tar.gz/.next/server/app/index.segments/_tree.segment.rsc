:HL["/_next/static/chunks/ab874d5ea0c67b8b.css","style"]
0:{"buildId":"YdWCqDLX8ZfQn9pwyZUcl","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
