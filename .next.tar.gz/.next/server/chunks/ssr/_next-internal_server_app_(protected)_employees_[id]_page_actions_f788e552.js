module.exports=[92848,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_employees_%5Bid%5D_page_actions_f788e552.js.map