module.exports=[33846,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_dashboard_kelas_create_page_actions_97dcdd4c.js.map