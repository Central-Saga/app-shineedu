module.exports=[68414,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_dashboard_kelas_%5Bid%5D_page_actions_08f4f371.js.map