module.exports=[85167,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_dashboard_murid_page_actions_9088a252.js.map