module.exports=[35775,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_absensi_page_actions_b8487c9a.js.map