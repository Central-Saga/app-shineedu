module.exports=[45135,(a,b,c)=>{}];

//# sourceMappingURL=bec2d_app_%28protected%29_dashboard_catalog_jenjang_%5Bid%5D_edit_page_actions_37aa43b3.js.map