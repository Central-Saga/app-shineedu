module.exports=[60298,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_dashboard_kelas_%5Bid%5D_edit_page_actions_271551f6.js.map