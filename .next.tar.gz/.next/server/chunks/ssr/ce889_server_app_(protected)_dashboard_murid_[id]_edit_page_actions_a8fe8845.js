module.exports=[61054,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_dashboard_murid_%5Bid%5D_edit_page_actions_a8fe8845.js.map