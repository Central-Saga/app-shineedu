module.exports=[50647,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_gaji_page_actions_8c499f19.js.map