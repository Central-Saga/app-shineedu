module.exports=[52207,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_dashboard_catalog_program_create_page_actions_6aa2107f.js.map