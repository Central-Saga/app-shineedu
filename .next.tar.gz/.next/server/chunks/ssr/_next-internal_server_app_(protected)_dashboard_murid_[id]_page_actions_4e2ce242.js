module.exports=[58922,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_dashboard_murid_%5Bid%5D_page_actions_4e2ce242.js.map