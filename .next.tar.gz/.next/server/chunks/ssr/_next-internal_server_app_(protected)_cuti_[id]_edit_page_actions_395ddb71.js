module.exports=[18708,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_cuti_%5Bid%5D_edit_page_actions_395ddb71.js.map