module.exports=[68951,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_gaji_preview_%5Bid%5D_page_actions_6f980527.js.map