module.exports=[22365,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_dashboard_murid_create_page_actions_8a47d144.js.map