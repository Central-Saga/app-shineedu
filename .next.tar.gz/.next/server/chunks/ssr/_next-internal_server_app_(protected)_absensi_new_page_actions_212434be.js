module.exports=[5255,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_absensi_new_page_actions_212434be.js.map