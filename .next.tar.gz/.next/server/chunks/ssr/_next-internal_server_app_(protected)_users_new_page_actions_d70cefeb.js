module.exports=[89619,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_users_new_page_actions_d70cefeb.js.map