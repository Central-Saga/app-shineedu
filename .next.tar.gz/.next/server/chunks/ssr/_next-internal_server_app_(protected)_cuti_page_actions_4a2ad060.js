module.exports=[96680,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_cuti_page_actions_4a2ad060.js.map