module.exports=[51111,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_gaji_%5Bid%5D_page_actions_9dadcff2.js.map