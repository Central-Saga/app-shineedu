module.exports=[1328,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_absensi_scan_page_actions_8b3c1fc7.js.map