module.exports=[64254,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_dashboard_catalog_paket_page_actions_5071253e.js.map