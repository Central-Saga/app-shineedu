module.exports=[33396,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_dashboard_catalog_paket_create_page_actions_2b653fc8.js.map