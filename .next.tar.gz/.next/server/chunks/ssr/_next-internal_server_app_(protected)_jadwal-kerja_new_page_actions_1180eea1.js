module.exports=[33935,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_jadwal-kerja_new_page_actions_1180eea1.js.map