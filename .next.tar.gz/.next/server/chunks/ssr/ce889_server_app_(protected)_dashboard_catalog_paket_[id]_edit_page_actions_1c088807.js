module.exports=[20072,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_dashboard_catalog_paket_%5Bid%5D_edit_page_actions_1c088807.js.map