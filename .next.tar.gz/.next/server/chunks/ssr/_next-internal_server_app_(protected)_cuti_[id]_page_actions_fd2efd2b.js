module.exports=[62957,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_cuti_%5Bid%5D_page_actions_fd2efd2b.js.map