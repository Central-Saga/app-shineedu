module.exports=[32006,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_jadwal-kerja_%5Bid%5D_page_actions_de021a51.js.map