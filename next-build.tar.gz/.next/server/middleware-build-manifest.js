globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/6e3f8fd0aa1f833a.js",
    "static/chunks/3c1b10063a7dc646.js",
    "static/chunks/7b52218c954dfa8e.js",
    "static/chunks/1ea72d1be604ca55.js",
    "static/chunks/5a5025548a46274f.js",
    "static/chunks/turbopack-4ec27fd3a5cb9ad7.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];