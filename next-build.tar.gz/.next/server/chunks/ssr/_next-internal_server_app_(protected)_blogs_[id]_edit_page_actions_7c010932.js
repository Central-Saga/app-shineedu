module.exports=[333809,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_blogs_%5Bid%5D_edit_page_actions_7c010932.js.map