module.exports=[621130,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_assessment_templates_%5Bid%5D_page_actions_416d4cc5.js.map