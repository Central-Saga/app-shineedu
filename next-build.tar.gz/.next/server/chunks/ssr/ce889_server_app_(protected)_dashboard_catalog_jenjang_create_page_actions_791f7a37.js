module.exports=[826211,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_dashboard_catalog_jenjang_create_page_actions_791f7a37.js.map