module.exports=[736508,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_dashboard_materi-modul_%5Bid%5D_page_actions_e13347a7.js.map