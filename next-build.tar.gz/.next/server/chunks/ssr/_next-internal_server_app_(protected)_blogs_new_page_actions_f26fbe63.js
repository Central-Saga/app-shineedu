module.exports=[352808,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_blogs_new_page_actions_f26fbe63.js.map