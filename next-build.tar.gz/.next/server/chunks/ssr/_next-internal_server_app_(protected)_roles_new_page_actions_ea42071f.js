module.exports=[399447,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_roles_new_page_actions_ea42071f.js.map