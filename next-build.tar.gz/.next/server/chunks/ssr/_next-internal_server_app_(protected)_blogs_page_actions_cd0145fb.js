module.exports=[961866,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_blogs_page_actions_cd0145fb.js.map