module.exports=[688049,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_job-vacancies_new_page_actions_115f68cf.js.map