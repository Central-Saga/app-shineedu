module.exports=[26294,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_gallery-landing_new_page_actions_fe02f5d1.js.map