module.exports=[232813,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_dashboard_materi-modul_create_page_actions_cd85076f.js.map