module.exports=[755066,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_assessment_templates_create_page_actions_d679744d.js.map