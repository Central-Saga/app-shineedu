module.exports=[840557,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_dashboard_catalog_program_page_actions_801d5ad2.js.map