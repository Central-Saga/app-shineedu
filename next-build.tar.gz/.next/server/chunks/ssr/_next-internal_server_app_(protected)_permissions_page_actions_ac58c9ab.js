module.exports=[47147,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_permissions_page_actions_ac58c9ab.js.map