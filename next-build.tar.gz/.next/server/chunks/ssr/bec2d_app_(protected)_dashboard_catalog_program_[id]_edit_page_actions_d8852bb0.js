module.exports=[800400,(a,b,c)=>{}];

//# sourceMappingURL=bec2d_app_%28protected%29_dashboard_catalog_program_%5Bid%5D_edit_page_actions_d8852bb0.js.map