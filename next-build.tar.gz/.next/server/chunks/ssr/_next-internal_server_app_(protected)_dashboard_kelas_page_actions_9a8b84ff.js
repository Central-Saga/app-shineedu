module.exports=[864118,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_dashboard_kelas_page_actions_9a8b84ff.js.map