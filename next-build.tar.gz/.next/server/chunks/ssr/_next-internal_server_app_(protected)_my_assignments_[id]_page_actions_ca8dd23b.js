module.exports=[385752,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_my_assignments_%5Bid%5D_page_actions_ca8dd23b.js.map