module.exports=[27847,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_dashboard_materi-modul_page_actions_f0790a91.js.map