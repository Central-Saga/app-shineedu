module.exports=[694312,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_blogs_%5Bid%5D_page_actions_72f79ba8.js.map