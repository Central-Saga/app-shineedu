module.exports=[934074,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_cuti_new_page_actions_30cdb4fc.js.map