module.exports=[456573,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_gallery-landing_page_actions_1039c089.js.map